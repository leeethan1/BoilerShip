﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class dialoguebehavior : MonoBehaviour
{
    public Image img;
    public Text name;
    public Text text;
    // Start is called before the first frame update
    void Start()
    {
        img.enabled = false;
        name.enabled = false;
        text.enabled = false;
    }

    public void Enable() {
        img.enabled = true;
        name.enabled = true;
        text.enabled = true;
    }


}
