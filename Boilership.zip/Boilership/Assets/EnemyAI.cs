﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyAI : MonoBehaviour
{
    private GameObject Player;
    public float speed;
 
     void Start () {
         Player = GameObject.Find("Starship");
     }
     void Update () {
        if (transform.position.x >= (Player.transform.position.x + 1)){
            transform.position = Vector2.MoveTowards(transform.position, Player.transform.position + new Vector3(1f, 1f), speed * Time.deltaTime);
        }else if(transform.position.x <= (Player.transform.position.x - 2)){
            transform.position = Vector2.MoveTowards(transform.position, Player.transform.position + new Vector3(-1f, -1f), speed * Time.deltaTime);
        }

     }
}
