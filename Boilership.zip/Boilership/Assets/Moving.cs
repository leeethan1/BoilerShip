﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Diagnostics;
using System.Threading;
using System;
using UnityEditor;



public class Moving : MonoBehaviour
{

    public float moveSpeed = 0f;
    public Vector2 jumpHeight;
    float velX;
    float velY;
    bool facingRight = true;
    bool isGrounded = true;
    Rigidbody2D rigBody;
    Vector2 offset;
    Stopwatch sw = new Stopwatch();
    public GameManager gameManager;
    bool gameOver = false;

    

    // Start is called before the first frame update
    void Start()
    {
        rigBody = GetComponent<Rigidbody2D> ();
        transform.position = new Vector2(-17, -5);
    }

    // Update is called once per frame
    void Update()
    {
        velX = Input.GetAxisRaw("Horizontal");
        velY = rigBody.velocity.y;
        rigBody.velocity = new Vector2(velX * moveSpeed, velY);
        transform.position = new Vector2 (rigBody.position.x + offset.x, rigBody.position.y + offset.y);
        if ((velY <= .3 && velY >= -.3)  && Input.GetKeyDown(KeyCode.W))  //makes player jump
        {
            rigBody.AddForce(jumpHeight, ForceMode2D.Impulse);

        }
        if (Input.GetKeyDown(KeyCode.R)) {
            transform.position = new Vector2(-17, -5);
        }

        if (rigBody.position.y <= -15) {
            transform.position = new Vector2(-17, -5);
        }
        TimeSpan ts = sw.Elapsed;
        // UnityEngine.Debug.Log(ts.Seconds);
        if (ts.Seconds >= 5) {
            sw.Stop();
            UnityEngine.Debug.Log("hi");
            sw.Reset();
            moveSpeed = 5f;

        // IU collision //
        

      
    }
    }                                                   
/* Power Up 1 */
    void OnTriggerEnter2D(Collider2D collision) {
        if (collision.tag == "Powerup") {    
            Destroy(collision.gameObject);
            moveSpeed = 10f;
            sw.Start();
        }
        
       if (collision.tag == "IUstudent") {
           
            Application.LoadLevel("Main");           

           // StartCoroutine(DieAndRespawn()); 

        } 
        if (collision.tag == "FratBoy"){
            UnityEngine.Debug.Log("TEst");
            Application.LoadLevel("Main");

        }

        if (collision.tag == "PPurdue"){
            if (!gameOver) {
                GameObject.Find("TextDialogue").GetComponent<dialoguebehavior>().Enable();
            }
        }

        /* IEnumerator DieAndRespawn() {
            yield return new WaitForSeconds(2.0f);
            transform.position = new Vector2(-17, -5); */

        
        
    }

    




    void LateUpdate() {
        Vector3 localScale = transform.localScale;
        if (velX > 0) {
            facingRight = true;
        } else if(velX < 0 ){
            facingRight = false;
        }
        if (((facingRight) && (localScale.x < 0)) || ((!facingRight) && (localScale.x > 0))){
            localScale.x *= -1;
        }
        transform.localScale = localScale;
    }

}