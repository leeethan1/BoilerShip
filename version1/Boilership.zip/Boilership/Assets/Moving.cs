﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Moving : MonoBehaviour
{

    public float moveSpeed = 0f;
    public Vector2 jumpHeight;
    float velX;
    float velY;
    bool facingRight = true;
    bool isGrounded = true;
    Rigidbody2D rigBody;
    Vector3 offset;

    // Start is called before the first frame update
    void Start()
    {
        rigBody = GetComponent<Rigidbody2D> ();
    }

    // Update is called once per frame
    void Update()
    {
        velX = Input.GetAxisRaw("Horizontal");
        velY = rigBody.velocity.y;
        rigBody.velocity = new Vector2(velX * moveSpeed, velY);
        transform.position = new Vector3 (rigBody.position.x + offset.x, rigBody.position.y + offset.y, offset.z);
        if ((velY <= .3 && velY >= -.3)  && Input.GetKeyDown(KeyCode.W))  //makes player jump
        {
            rigBody.AddForce(jumpHeight, ForceMode2D.Impulse);

        }
        if (Input.GetKeyDown(KeyCode.R)) {
            transform.position = new Vector3(-17, -5, 0);
        }

        if (rigBody.position.y <= -15) {
            transform.position = new Vector3(-17, -5, 0);
        }
    }
/* Power Up 1 */
    void OnTriggerEnter2D(Collider2D collision) {
        if (collision.tag == "Powerup") {
            Destroy(collision.gameObject);
            moveSpeed = 10f; 
        }
    }


    void LateUpdate() {
        Vector3 localScale = transform.localScale;
        if (velX > 0) {
            facingRight = true;
        } else if(velX < 0 ){
            facingRight = false;
        }
        if (((facingRight) && (localScale.x < 0)) || ((!facingRight) && (localScale.x > 0))){
            localScale.x *= -1;
        }
        transform.localScale = localScale;
    }

}