﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class power1 : MonoBehaviour
{
    public float sizebuff = 5f;
    public float speedbuff = 3f;
    public float duration = 10f;    
    

    public GameObject pickupEffect;

    void OnTriggerEnter(Collider2D other)  /* other = Player */
    {
        if (other.CompareTag("Player"))            /* when player's tag collides with the denpop, trigger the effect */
        {
           StartCoroutine( Pickup1(other) );      /* Declares Pickup1 as a function */
        }
    }
    IEnumerator Pickup1(Collider2D player)
    { 
        // Particle effect
        Instantiate(pickupEffect, transform.position, transform.rotation);

        // Add effect
        player.transform.localScale *= sizebuff;            /* Size Buff to indicate change to player */
        Moving stats = player.GetComponent<Moving>();            /* Retrieves player's speed stat from the Player Stats script */
        stats.moveSpeed = 6f;
        /* Disable graphics and box collider to incapcitate the object */   
        GetComponent<MeshRenderer>().enabled = false;
        GetComponent<Collider2D>().enabled = false;

        // Wait out an interval of time
        yield return new WaitForSeconds (duration);

        // Undo effect
        stats.moveSpeed = 3f;

        // Remove from field
        Destroy(gameObject);



    }
}

